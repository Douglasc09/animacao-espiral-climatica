dados <- read.table("...caminho/dados/climate_dataframe.txt", header = T, sep = ",")
#################################################################
library(tidyverse)
library(ggplot2)
library(gganimate)
library(gifski)
library(viridisLite)
library(viridis)
################################################################
#definindo constante que será usada no gráfico
const <- abs(min(dados$Temp)) + 0.1

media_51_80 <- dados %>%
  filter(Year >= 1951, Year <= 1980) %>%
  summarise(media = mean(Temp, na.rm = TRUE)) %>%
  pull(media)

r_media_51_80 <- media_51_80 + const

#ANÉIS DE TEMPERATURA
aneis_temp <- tibble(
  temp = c(0, 1, 2),
  r = temp + const
)

#RÓTULOS DOS ANÉIS
labels_temp <- tibble(
  label = c("0°C", "+1°C", "+2°C"),
  theta = pi/2,
  r = c(0, 1, 2) + const
)

#CORREÇÃO: PARA FECHAR O CICLO, ESTAVA FICANDO UM VÃO PRETO SEM DADOS
dados <- dados |>
  group_by(Year) |>
  bind_rows(
    dados |>
      filter(theta == 0) |>
      mutate(theta = 2*pi)
  ) |>
  ungroup()

meses_chave <- tibble(
  theta = 2*pi*((0:11) + 0.5)/12
)

nomes_meses_chave <- tibble(
  Month = c("Jan", "Feb", "Mar", "Apr", "May", "Jun",
            "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"),
  theta = 2*pi*(0:11)/12,
  r = max(dados$r) + 0.2
)

#########################################################
dados <- dados %>% 
  arrange(Year, theta)

anim <- ggplot(dados, aes(
  x = theta,
  y = r,
  group = Year,
  colour = Year
))+
  geom_path(alpha = 0.6, linewidth = 0.4) +
  
  #LINHA DE REFERÊNCIA 1951–1980
  geom_hline(yintercept = r_media_51_80,
             colour = "white",
             linewidth = 0.8,
             alpha = 0.8) +
  
  ##ANÉIS DE TEMPERATURA
  geom_hline(
    data = aneis_temp,
    aes(yintercept = r),
    colour = "yellow",
    linewidth = 0.6,
    alpha = 0.9
  ) +
  
  #RÓTULOS DOS ANÉIS
  geom_text(
    data = labels_temp,
    aes(x = theta, y = r, label = label),
    inherit.aes = FALSE,
    colour = "yellow",
    size = 4,
    fontface = "bold"
  ) +
  
  geom_segment(
    data = meses_chave,
    aes(
      x = theta,
      xend = theta,
      y = min(dados$r),
      yend = max(dados$r)
    ),
    inherit.aes = FALSE,
    colour = "white",
    linewidth = 0.3,
    alpha = 0.4
  )+
  geom_text(
    data = nomes_meses_chave,
    aes(
      x = theta,
      y = r,
      label = Month
    ),
    inherit.aes = FALSE,
    colour = "white",
    size = 4,
    fontface = "bold"
  )+
  coord_polar(start = -pi/12, direction = 1)+
  scale_colour_viridis_c(option = "magma",
                         begin = 0.1,
                         end = 0.95)+
  theme_void() +
  theme(
    plot.background = element_rect(fill = "black", color = NA),
    panel.background = element_rect(fill = "black", color = NA),
    plot.title = element_text(color = "white", size = 16, face = "bold"),
    plot.subtitle = element_text(color = "gray80", size = 11),
    legend.position = "right",
    legend.title = element_text(color = "white"),
    legend.text = element_text(color = "white"),
    plot.margin = margin(10, 10, 10, 10)
  )+
  labs(
    title = "Anomalias de Temperatura Globais",
    subtitle = "Anomalias mensais da temperatura média global",
    colour = "Year"
  ) + transition_reveal(Year)

animacao <- animate(anim,
                    nframes = 450,
                    fps = 30,
                    width = 800,
                    height = 800,
                    renderer = gifski_renderer()
)

anim_save("...caminho/media/espiral_clima.gif",
          animation = animacao)



