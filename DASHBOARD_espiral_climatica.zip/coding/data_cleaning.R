library(tidyr)
library(dplyr)
    
#IMPORTACAO
df_wide <- read.csv("C:/Users/Douglas/Desktop/coding/R/trabalhos/est_comp1/DASHBOARD_trabalho_final/dados/GLB.Ts+dSST.csv", skip = 1)
df_wide <- df_wide[-c(14:19)]
#WIDE TO LONG
meses <- colnames(df_wide[-1])
df_long <- df_wide %>% 
  pivot_longer(
    cols = meses,
    names_to = "Month",
    values_to = "Temp"
  )

#ORGANIZANDO MESES NA ORDEM CERTA
df_long <- df_long %>% 
  mutate(
    Month = factor(Month, levels = meses)
  )
#TRANSFORMANDO OS MESES EM ANGULOS
df_long <- df_long %>% 
  mutate(
    mes_numerico = as.numeric(Month),
    theta = 2*pi*(mes_numerico - 1)/12
  )
#GARANTINDO QUE NÃO TEREMOS VALORES NEGATIVOS EM COORDENADAS POLARES
minimo <- min(df_long$Temp)
const <- abs(minimo) + 0.1
#CRIANDO A VARIAVEL RAIO
df_long <- df_long %>% 
  mutate(
    r = Temp + const
  )

#SALVANDO O DATAFRAME
write.table(df_long, "C:/Users/Douglas/Desktop/coding/R/trabalhos/est_comp1/DASHBOARD_trabalho_final/dados/climate_dataframe.txt", sep = ",", row.names = F)

